CREATE PROCEDURE assetCountBasedOnStatus(IN type VARCHAR(24))
  BEGIN
    SELECT
      c.cat_name,
      COUNT(a.sub_cat_id) AS quantity
    FROM asset_category AS c
      LEFT JOIN asset AS a ON c.cat_id = a.sub_cat_id
    WHERE c.cat_status = 0 AND a.isAvailable=type
    GROUP BY c.cat_id;
  END;
