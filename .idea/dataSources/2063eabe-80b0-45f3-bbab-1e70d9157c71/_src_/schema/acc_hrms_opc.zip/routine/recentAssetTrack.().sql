CREATE PROCEDURE recentAssetTrack()
  BEGIN
    SELECT
      t.ass_track_id,
      t.Asset_ass_id,
      t.reciver_full_name,
      greatest(max(t.date_returned), max(t.date_trasferred)) AS recentDate,
      t.ass_emp_id,
      a.ass_serial_number,
      a.ass_name
    FROM ass_track AS t
      LEFT JOIN asset AS a
        ON t.Asset_ass_id = a.ass_id
    GROUP BY Asset_ass_id;
  END;
