CREATE PROCEDURE assetTrackDetailById(IN assId INT(22))
  BEGIN
    SELECT *
    FROM ass_track
    WHERE asset_ass_id = assId;
  END;
