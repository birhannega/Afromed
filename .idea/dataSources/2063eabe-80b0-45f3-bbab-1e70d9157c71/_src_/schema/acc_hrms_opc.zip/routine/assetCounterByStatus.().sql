CREATE PROCEDURE assetCounterByStatus()
  BEGIN
    SELECT s.status, count(a.status_status_id) AS total
      FROM status AS s
        LEFT JOIN asset as a on s.status_id=a.status_status_id
    GROUP BY s.status_id;

  END;
