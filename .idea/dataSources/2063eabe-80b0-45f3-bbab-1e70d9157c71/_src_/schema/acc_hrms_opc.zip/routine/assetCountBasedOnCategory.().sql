CREATE PROCEDURE assetCountBasedOnCategory()
  BEGIN
    SELECT
      c.cat_id,
      c.cat_code,
      c.cat_name,
      c.depriciation_life,
      COUNT(a.sub_cat_id) AS quantity
    FROM asset_category AS c
      LEFT JOIN asset AS a ON c.cat_id = a.sub_cat_id
    WHERE c.cat_status = 0
    GROUP BY c.cat_id;
  END;
