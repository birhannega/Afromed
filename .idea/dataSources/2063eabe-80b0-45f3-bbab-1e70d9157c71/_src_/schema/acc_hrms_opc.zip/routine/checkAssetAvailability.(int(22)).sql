CREATE PROCEDURE checkAssetAvailability(IN id INT(22))
  BEGIN

    SELECT
      status,
      greatest(max(date_trasferred), max(date_returned))
    FROM ass_track
    WHERE Asset_ass_id = id;
  END;
